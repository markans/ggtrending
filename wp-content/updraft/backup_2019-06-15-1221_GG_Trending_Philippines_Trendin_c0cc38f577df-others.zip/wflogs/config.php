<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:6:{s:9:"wafStatus";s:7:"enabled";s:30:"learningModeGracePeriodEnabled";i:0;s:7:"authKey";s:64:"kx:e|Z8JTb{.i)ift3ao2*^3.vYl,yJ6;9|q%uhETj<5F0^>~i{<{/YrLC{~=UP0";s:7:"version";s:5:"1.0.4";s:13:"attackDataKey";i:1842;s:11:"wafDisabled";b:0;}